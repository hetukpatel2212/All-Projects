const menuBtn = document.querySelector("#menu");
const sideMenu = document.querySelector("#sidebar");
const menuClose = document.querySelector("#menuClose");
const iconSidebar = document.querySelector(".icon-sidebar");
const videoOpen = document.querySelector(".videoOpen");
const videoClose = document.querySelector(".videoClose");
const dropdown = document.querySelector(".dropdown");
const category = document.querySelector(".top-category");
const mainContent = document.querySelector(".main-content");
const contentInformation1 = document.querySelector("#id1");
const contentInformation2 = document.querySelector("#id2");
const contentInformation3 = document.querySelector("#id3");
const contentInformation4 = document.querySelector("#id4");
const contentInformation5 = document.querySelector("#id5");
const contentInformation6 = document.querySelector("#id6");
const contentInformation7 = document.querySelector("#id7");
const contentInformation8 = document.querySelector("#id8");
const contentInformation9 = document.querySelector("#id9");
const contentInformation10 = document.querySelector("#id10");
const contentInformation11 = document.querySelector("#id11");
const text = document.querySelector(".text");
const readMoreBtn = document.querySelector(".read-more-btn");
const commentText = document.querySelector("#commentText");
const buttons = document.querySelector(".buttons");
const cancel = document.querySelector(".cancel");

menuBtn.addEventListener('click', () => {
    sideMenu.style.display = 'none';
    menuBtn.style.display = 'none';
    menuClose.style.display = 'block';
    iconSidebar.style.display = 'block';
    category.style.marginLeft = '-150px';
    mainContent.style.marginLeft = '-100px';
    contentInformation1.style.width = '23%';
    contentInformation2.style.width = '23%';
    contentInformation3.style.width = '23%';
    contentInformation4.style.width = '23%';
    contentInformation5.style.width = '23%';
    contentInformation6.style.width = '23%';
    contentInformation7.style.width = '23%';
    contentInformation8.style.width = '23%';
    contentInformation9.style.width = '23%';
    contentInformation10.style.width = '23%';
    contentInformation11.style.width = '23%';
})

menuClose.addEventListener('click', () => {
    sideMenu.style.display = 'block';
    menuBtn.style.display = 'block';
    menuClose.style.display = 'none';
    iconSidebar.style.display = 'none';
    category.style.marginLeft = '0px';
    mainContent.style.marginLeft = '0px';
    contentInformation1.style.width = '31%';
    contentInformation2.style.width = '31%';
    contentInformation3.style.width = '31%';
    contentInformation4.style.width = '31%';
    contentInformation5.style.width = '31%';
    contentInformation6.style.width = '31%';
    contentInformation7.style.width = '31%';
    contentInformation8.style.width = '31%';
    contentInformation9.style.width = '31%';
    contentInformation10.style.width = '31%';
    contentInformation11.style.width = '31%';
})

videoOpen.addEventListener('click', () => {
    dropdown.style.display = 'block';
    videoOpen.style.display = 'none';
    videoClose.style.display = 'block';
})

videoClose.addEventListener('click', () => {
    dropdown.style.display = 'none';
    videoOpen.style.display = 'block';
    videoClose.style.display = 'none';
})

readMoreBtn.addEventListener('click', (e) => {
    text.classList.toggle('show-more');
    if (readMoreBtn.innerText == 'Read more') {
        readMoreBtn.style.fontWeight = '700';
        readMoreBtn.innerText = 'Read less';
    } else {
        readMoreBtn.innerText = 'Read more';
    }
})

commentText.addEventListener('click', () => {
    buttons.style.display = 'block';
})

cancel.addEventListener('click', () => {
    buttons.style.display = 'none';
})
